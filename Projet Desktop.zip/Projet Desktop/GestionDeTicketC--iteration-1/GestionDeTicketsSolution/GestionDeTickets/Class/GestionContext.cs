﻿using System.Data.Entity;

namespace GestionDeTickets.Class
{
    public class GestionContext : DbContext
    {
        public GestionContext()
            :base("Data Source=DESKTOP-5C3JN1P\\SQLEXPRESS;Initial Catalog=gestiondetickets;Persist Security Info=True;Trusted_Connection=Yes")
        {} //Permet de créer les tables dans le mssql renseigné, initial catalog est la bdd concerné

        public DbSet<Personne> Personnes { get; set; }

        public DbSet<Ticket> Tickets { get; set; }

        public DbSet<Commentaire> Commentaires { get; set; }

    }
}
