﻿using System.Data.Linq.Mapping;

namespace GestionDeTickets.Class
{
    public class Technicien : Personne
    {
        public int Niveau { get; set; }
    }
}
