﻿using System.Data.Linq.Mapping;

namespace GestionDeTickets.Class
{
    public class Utilisateur : Personne
    {
        public bool Vip { get; set; }

    }
}
